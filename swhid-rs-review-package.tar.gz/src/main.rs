use clap::{Parser, Subcommand};
use std::path::PathBuf;

use swhid::{Content, DiskDirectoryBuilder, WalkOptions};
use swhid::{QualifiedSwhid, Swhid};
use swhid::config::HashConfig;

#[cfg(feature = "git")]
use swhid::git;

/// Small CLI for the SWHID reference implementation
#[derive(Parser, Debug)]
#[command(name = "swhid")]
#[command(about = "Compute and parse SWHIDs (ISO/IEC 18670)")]
struct Cli {
    /// SWHID version (1 or 2)
    #[arg(long, value_name = "VERSION", default_value = "1")]
    version: String,
    /// Hash function (sha1 or sha256)
    #[arg(long, value_name = "HASH", default_value = "sha1")]
    hash: String,
    /// Serialization format (hex, base64, or base64url)
    #[arg(long, value_name = "FORMAT", default_value = "hex")]
    serialization: String,
    #[command(subcommand)]
    cmd: Command,
}

#[derive(Subcommand, Debug)]
enum Command {
    /// Compute a content SWHID from stdin or a file
    Content {
        /// Path to file (if omitted, read stdin)
        #[arg(short, long)]
        file: Option<PathBuf>,
    },
    /// Compute a directory SWHID recursively
    Dir {
        /// Directory root
        path: PathBuf,
        /// Follow symlinks (not recommended)
        #[arg(long)]
        follow_symlinks: bool,
        /// Exclude files matching these suffixes (e.g., .tmp, .log)
        #[arg(long, value_name = "SUFFIX")]
        exclude: Vec<String>,
    },
    /// Parse/pretty-print a (qualified) SWHID
    Parse {
        /// The SWHID string
        swhid: String,
    },
    /// Verify that a file or directory matches a given SWHID
    Verify {
        /// Path to file or directory
        path: PathBuf,
        /// Expected SWHID
        swhid: String,
        /// Follow symlinks (not recommended)
        #[arg(long)]
        follow_symlinks: bool,
        /// Exclude files matching these suffixes (e.g., .tmp, .log)
        #[arg(long, value_name = "SUFFIX")]
        exclude: Vec<String>,
    },
    /// Git repository SWHID computation (requires --features git)
    #[cfg(feature = "git")]
    Git {
        #[command(subcommand)]
        cmd: GitCommand,
    },
}

#[cfg(feature = "git")]
#[derive(Subcommand, Debug)]
enum GitCommand {
    /// Compute revision SWHID for a commit
    Revision {
        /// Git repository path
        repo: PathBuf,
        /// Commit hash (if omitted, use HEAD)
        commit: Option<String>,
    },
    /// Compute release SWHID for a tag
    Release {
        /// Git repository path
        repo: PathBuf,
        /// Tag name
        tag: String,
    },
    /// Compute snapshot SWHID for a repository
    Snapshot {
        /// Git repository path
        repo: PathBuf,
    },
    /// List all tags in a repository
    Tags {
        /// Git repository path
        repo: PathBuf,
    },
}

fn get_hash_config(version: &str, hash: &str, serialization: &str) -> Result<HashConfig, Box<dyn std::error::Error>> {
    // Validate version
    if version != "1" && version != "2" {
        return Err(format!("Invalid version: {}. Must be 1 or 2", version).into());
    }

    // Validate hash
    if hash != "sha1" && hash != "sha256" {
        return Err(format!("Invalid hash: {}. Must be sha1 or sha256", hash).into());
    }

    // Validate serialization
    if serialization != "hex" && serialization != "base64" && serialization != "base64url" 
        && serialization != "base32" && serialization != "base32hex" && serialization != "z85" {
        return Err(format!("Invalid serialization: {}. Must be hex, base64, base64url, base32, base32hex, or z85", serialization).into());
    }

    // Create appropriate config
    match (version, hash, serialization) {
        ("1", "sha1", "hex") => Ok(HashConfig::v1()),
        ("2", "sha256", "hex") => Ok(HashConfig::v2_sha256_hex()),
        ("2", "sha256", "base64") => Ok(HashConfig::v2_sha256_base64()),
        ("2", "sha256", "base64url") => Ok(HashConfig::v2_sha256_base64url()),
        ("2", "sha256", "base32") => Ok(HashConfig::v2_sha256_base32()),
        ("2", "sha256", "base32hex") => Ok(HashConfig::v2_sha256_base32hex()),
        ("2", "sha256", "z85") => Ok(HashConfig::v2_sha256_z85()),
        ("2", "sha1", "hex") => Ok(HashConfig::v1()), // v2 with sha1+hex is same as v1
        _ => Err(format!(
            "Invalid combination: version={}, hash={}, serialization={}. \
            v1 only supports sha1+hex. v2 supports sha256 with hex/base64/base64url/base32/base32hex/z85",
            version, hash, serialization
        ).into()),
    }
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cli = Cli::parse();
    let config = get_hash_config(&cli.version, &cli.hash, &cli.serialization)?;
    let use_v2 = cli.version == "2";
    
    match cli.cmd {
        Command::Content { file } => {
            let bytes = if let Some(p) = file {
                std::fs::read(p)?
            } else {
                use std::io::Read;
                let mut buf = Vec::new();
                std::io::stdin().read_to_end(&mut buf)?;
                buf
            };
            let content = Content::from_bytes(bytes);
            let s = if use_v2 {
                content.swhid_with_config(&config)
            } else {
                content.swhid()
            };
            println!("{s}");
        }
        Command::Dir {
            path,
            follow_symlinks,
            exclude,
        } => {
            let mut opts = WalkOptions {
                follow_symlinks,
                ..Default::default()
            };
            opts.exclude_suffixes = exclude;
            let dir = DiskDirectoryBuilder::new(&path)
                .with_options(opts);
            let s = if use_v2 {
                dir.swhid_with_config(&config)?
            } else {
                dir.swhid()?
            };
            println!("{s}");
        }
        Command::Parse { swhid } => {
            // Try qualified first, fallback to core
            match swhid.parse::<QualifiedSwhid>() {
                Ok(q) => println!("{q}"),
                Err(_) => {
                    let core: Swhid = swhid.parse()?;
                    println!("{core}");
                }
            }
        }
        Command::Verify {
            path,
            swhid,
            follow_symlinks,
            exclude,
        } => {
            let expected: Swhid = swhid.parse()?;
            let actual = if path.is_file() {
                let bytes = std::fs::read(&path)?;
                let content = Content::from_bytes(bytes);
                if use_v2 {
                    content.swhid_with_config(&config)
                } else {
                    content.swhid()
                }
            } else if path.is_dir() {
                let mut opts = WalkOptions {
                    follow_symlinks,
                    ..Default::default()
                };
                opts.exclude_suffixes = exclude;
                let dir = DiskDirectoryBuilder::new(&path)
                    .with_options(opts);
                if use_v2 {
                    dir.swhid_with_config(&config)?
                } else {
                    dir.swhid()?
                }
            } else {
                eprintln!(
                    "Error: {} is neither a file nor a directory",
                    path.display()
                );
                std::process::exit(1);
            };

            if actual == expected {
                println!(
                    "✓ Verification successful: {} matches {}",
                    path.display(),
                    expected
                );
                std::process::exit(0);
            } else {
                println!(
                    "✗ Verification failed: {} does not match {}",
                    path.display(),
                    expected
                );
                println!("  Expected: {expected}");
                println!("  Actual:   {actual}");
                std::process::exit(1);
            }
        }
        #[cfg(feature = "git")]
        Command::Git { cmd } => match cmd {
            GitCommand::Revision { repo, commit } => {
                let repo = git::open_repo(&repo)?;
                let commit_oid = if let Some(commit_str) = commit {
                    git2::Oid::from_str(&commit_str)
                        .map_err(|e| format!("Invalid commit hash: {e}"))?
                } else {
                    git::get_head_commit(&repo)?
                };
                let swhid = git::revision_swhid(&repo, &commit_oid)?;
                println!("{swhid}");
            }
            GitCommand::Release { repo, tag } => {
                let repo = git::open_repo(&repo)?;
                let tag_oid = repo
                    .refname_to_id(&format!("refs/tags/{tag}"))
                    .map_err(|e| format!("Tag not found: {e}"))?;
                let swhid = git::release_swhid(&repo, &tag_oid)?;
                println!("{swhid}");
            }
            GitCommand::Snapshot { repo } => {
                let repo = git::open_repo(&repo)?;
                let swhid = git::snapshot_swhid(&repo)?;
                println!("{swhid}");
            }
            GitCommand::Tags { repo } => {
                let repo = git::open_repo(&repo)?;
                let tags = git::get_tags(&repo)?;
                for tag_oid in tags {
                    println!("{tag_oid}");
                }
            }
        },
    }
    Ok(())
}
